import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';

import { userService } from '../shared/user.service';
import {useruser } from '../shared/user.model';

declare var M: any;

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css'],
  providers: [userService]
})
export class userComponent implements OnInit {

  constructor(private userService: userService) { }

  ngOnInit() {
    this.resetForm();
    this.refreshuserList();
  }

  resetForm(form?: NgForm) {
    if (form)
      form.reset();
    this.userService.selecteduser = {
      _id: "",
      name: "",
      city: "",
      DOB: "",
      contactNo: null
    }
  }

  onSubmit(form: NgForm) {
    if (form.value._id == "") {
      this.userService.postuser(form.value).subscribe((res) => {
        this.resetForm(form);
        this.refreshuserList();
        M.toast({ html: 'Saved successfully', classes: 'rounded' });
      });
    }
    else {
      this.userService.putuser(form.value).subscribe((res) => {
        this.resetForm(form);
        this.refreshuserList();
        M.toast({ html: 'Updated successfully', classes: 'rounded' });
      });
    }
  }

  refreshuserList() {
    this.userService.getuserList().subscribe((res) => {
      this.userService.userdetails = res as user[];
    });
  }

  onEdit(usr: user) {
    this.userService.selecteduser = emp;
  }

  onDelete(_id: string, form: NgForm) {
    if (confirm('Are you sure to delete this record ?') == true) {
      this.userService.deleteuser(_id).subscribe((res) => {
        this.refreshuserList();
        this.resetForm(form);
        M.toast({ html: 'Deleted successfully', classes: 'rounded' });
      });
    }
  }

}
