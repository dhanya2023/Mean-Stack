export class user {
    _id: string;
    uname: string;
    city: string;
    DOB: number;
    contactNo: number;
}
