const mongoose = require('mongoose');

var user = mongoose.model('user', {
    uname: { type: String },
    city: { type: String },
    DOB: { type: Number },
    contactNo: { type: Number }
});

module.exports = { user };